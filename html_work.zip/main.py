import json

from flask import Flask, url_for, render_template, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


class LoginForm(FlaskForm):
    user1 = StringField('Id астронавта', validators=[DataRequired()])
    pass1 = PasswordField('Пароль астронавта', validators=[DataRequired()])
    user2 = StringField('Id капитана', validators=[DataRequired()])
    pass2 = PasswordField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('login.html', title='Аварийный доступ', form=form,
                           emblem=url_for('static', filename='img/MARS-2-7.png'))


@app.route('/')
@app.route('/index')
def index():
    return render_template('base.html')


@app.route('/training/<prof>')
def training(prof):
    if "строитель" in prof or "инженер" in prof:
        param = {"url": url_for('static', filename='img/engineer.jpg'), "title": "Инженерные тренажеры"}
    else:
        param = {"url": url_for('static', filename='img/science.jpg'), "title": "Научные симуляторы"}
    return render_template('training.html', **param)


@app.route('/table/<gender>/<age>')
def tabling(gender, age):
    param = {"title": "Цвет каюты"}
    if int(age) < 21:
        param["pic_url"] = url_for('static', filename='img/young_alien.jpg')
    else:
        param["pic_url"] = url_for('static', filename='img/old_alien.jpg')
    if gender == "female":
        if int(age) < 21:
            param["color"] = "#f27979"
        else:
            param["color"] = "#a32929"
    else:
        if int(age) < 21:
            param["color"] = "#79a3f2"
        else:
            param["color"] = "#1c3a70"
    return render_template('tabling.html', **param)


@app.route('/list_prof/<tp>')
def list_prof(tp):
    prof_list = ["инженер-исследователь", "пилот", "строитель", "экзобиолог", "врач",
                 "инженер по терраформированию", "климатолог", "специалист по радиационной защите",
                 "астрогеолог", "гляциолог", "инженер жизнеобеспечения", "метеоролог", "оператор марсохода",
                 "киберинженер", "штурман", "пилот дронов"]
    if tp not in ["ol", "ul"]:
        return """<h1>Ошибка<h1>"""
    return render_template('list_prof.html', tp=tp, prof_list=prof_list)


@app.route('/answer')
@app.route('/auto_answer')
def answers():
    params = {
        "title": "Анкета",
        "surname": "Такойтович",
        "name": "Кто-то",
        "education": "какое-то",
        "profession": "а зачем спрашиваете?",
        "sex": "а кто это спрашивает?",
        "motivation": "а может я не хочу говорить",
        "ready": "False",
        "css_file": url_for('static', filename='css/style.css')
    }
    return render_template('auto_answer.html', **params)


@app.route('/distribution')
def distr():
    params = {
        "title": "Размещение",
        "names": ["Пётр Петрович", "Иван Иванов", "Николай Кузнецов", "Александр 2"],
        "css_file": url_for('static', filename='css/style.css')
    }
    return render_template('distribution.html', **params)


@app.route('/success')
def success():
    return render_template('success.html')


@app.route('/odd_even')
def odd_even():
    return render_template('odd_even.html', number=2)


@app.route('/news')
def news():
    with open("static/json/news.json", "rt", encoding="utf8") as f:
        news_list = json.loads(f.read())
    print(news_list)
    return render_template('news.html', news=news_list)


@app.route('/queue')
def que():
    return render_template('queue.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
